//const TicTacToe = require('./tictactoe');

class Player {
    constructor(symbol) {
        this.symbol = symbol;
    }
}

module.exports = Player; 