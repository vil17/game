
class Square {
    constructor(sign) {
        this.box = "";
        this.printSquare = function () {
            return this.box;
        };
        this.checkSquare = function (newsign) {
            this.box = newsign;
        };
        this.isEmpty = function () {
            if (this.box === "") {
                //console.log('ssquare is empty');
                return true;
            } else {
               // console.log('square is not empty')
                return false;
            }
        }
    }
}

module.exports = Square; 