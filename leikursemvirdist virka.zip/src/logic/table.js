const Square = require('./square');

class Table {
    constructor(sign) {
        this.counter = 0;
        this.squares = [[new Square(sign), new Square(sign), new Square(sign)],
        [new Square(sign), new Square(sign), new Square(sign)],
        [new Square(sign), new Square(sign), new Square(sign)]
        ];
        this.printSquares = function () {
            this.squares.forEach(row => {
                row.forEach(kubb => {
                    console.log(kubb.box);
                    return kubb.box;
                })
            })
        }
        this.makeMove = function (var1, var2, playerTurn) {
            console.log(var1,var2,playerTurn + "makemovefall");
            if (this.squares[var1][var2].isEmpty()) {
                this.squares[var1][var2].checkSquare(playerTurn);
                this.counter++;
                return true;
            }else{
                return false;
            }
        }
        this.gameEnded = function () {
            // Horizontal check 
            for (var i = 0; i < 3; i++) {
                if (this.grid[i][0].box === this.grid[i][1].box &&
                    this.grid[i][0].box === this.grid[i][2].box &&
                    this.grid[i][0].box != '') {
                    return true
                }
            }
            // Vertical check 
            for (var j = 0; j < 3; j++) {
                if (this.grid[0][j].box === this.grid[1][j].box &&
                    this.grid[0][j].box === this.grid[2][j].box &&
                    this.grid[0][j].box != '') {
                    return true;
                }

            }
            // KRISSKROSS
            if (this.grid[0][0].box == this.grid[1][1].box &&
                this.grid[0][0].box == this.grid[2][2].box &&
                this.grid[0][0].box != "" ||
                this.grid[0][2].box == this.grid[1][1].box &&
                this.grid[0][2].box == this.grid[2][0].box &&
                this.grid[0][2].box != "") {
                return true;
            } else if (counter === 9) {
                return true;
            } else {
                return false;
            }

        }
    }
}



module.exports = Table; 