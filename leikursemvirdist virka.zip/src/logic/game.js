//const TicTacToe = require("./tictactoe");
const Table = require("./table");
//const Player = require("./player");
//const Square = require("./square");


class Game {
    constructor() {
        console.log('Creating game.....');
        this.table = new Table("\'\'");
        this.gameStatus = true;
        this.playerTurn = 'X'; //of einfalt til ad vera setja i constructor
        this.gameEnded = function () {
            if (this.table.gameEnded) {
                this.gameStatus = false;
            }
        }
        this.changePlayer = function () {
            if (this.playerTurn === "X") {
                console.log('this.playerturn is ' + this.playerTurn);
                this.playerTurn = "O";
                return;
            } {
                console.log('this.playerturn is ' + this.playerTurn);
                this.playerTurn = "X";
            }
        };
        this.printTable = function () {
            return this.table.printSquares();
        };
        this.makeMove = function (var1, var2) {
            if (this.table.makeMove(var1, var2, this.playerTurn)) {
                this.changePlayer();
            }
            else { console.log('not alloweds') };
        }
    }
}
module.exports = Game; 