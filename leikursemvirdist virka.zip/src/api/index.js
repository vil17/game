const express = require("express");
const router = express.Router();
const game = require("../logic/game");

var newGame = new game();
  newGame.makeMove(0,0);
  newGame.printTable();
  newGame.makeMove(0,0);
  newGame.printTable();


router.get("/", (req, res) => {
  res.status(405).send({ error: "GET method not allowed here, try OPTIONS." });
});

router.options("/", (req, res) => {
  const options = {
    options: { get: ["/newgame", "/resetboard"] }
  };
  res.status(200).send(options);
});

router.get("/", (req, res) => {
  res.status(200).send("");
});

module.exports = router;