/* fetch('/game').then(res => {
     return res.json();
 }).then(function (body) {
     body.
   })
*/